import json
import joblib
import numpy as np
import os

def init():
    global model, scaler
    model_root = os.environ.get("AZUREML_MODEL_DIR", "")
    model = joblib.load(os.path.join(model_root, "model_artifacts", "sheep_anomaly_model.pkl"))
    scaler = joblib.load(os.path.join(model_root, "model_artifacts", "scaler.pkl"))

def analyze_animal(data):
    features = np.array([[
        data["motion_level"],
        data["respiration_rate"],
        data["heart_rate_bpm"],
        data["body_temp_c"],
        data["env_temp_c"]
    ]])
    features_scaled = scaler.transform(features)
    prediction = model.predict(features_scaled)[0]
    score = model.decision_function(features_scaled)[0]
    is_sick = bool(prediction == -1)

    if is_sick:
        temp    = data["body_temp_c"]
        heart   = data["heart_rate_bpm"]
        resp    = data["respiration_rate"]
        motion  = data["motion_level"]
        weather = data["env_temp_c"]
        species = data.get("animal_type", "sheep").lower()

        thresholds = {
            "sheep":  {"temp_high": 39.5, "temp_low": 38.5, "heart_high": 90,  "heart_low": 60,  "resp_high": 25, "resp_low": 12, "motion_low": 10},
            "goat":   {"temp_high": 39.5, "temp_low": 38.5, "heart_high": 90,  "heart_low": 70,  "resp_high": 30, "resp_low": 15, "motion_low": 10},
            "cow":    {"temp_high": 39.0, "temp_low": 38.0, "heart_high": 84,  "heart_low": 48,  "resp_high": 30, "resp_low": 15, "motion_low": 5},
            "camel":  {"temp_high": 38.5, "temp_low": 36.0, "heart_high": 50,  "heart_low": 25,  "resp_high": 15, "resp_low": 6,  "motion_low": 3},
        }

        t = thresholds.get(species, thresholds["sheep"])
        causes = []

        if temp > t["temp_high"]:
            causes.append("fever / heat stress")
        elif temp < t["temp_low"]:
            causes.append("hypothermia")

        if heart > t["heart_high"]:
            causes.append("tachycardia - possible infection")
        elif heart < t["heart_low"]:
            causes.append("bradycardia")

        if resp > t["resp_high"]:
            causes.append("respiratory distress")
        elif resp < t["resp_low"]:
            causes.append("abnormally low respiration")

        if motion < t["motion_low"]:
            causes.append("low activity / lethargy")

        if weather > 35 and temp > t["temp_high"]:
            causes.append("heat stroke risk")

        cause = ", ".join(causes) if causes else "general anomaly - abnormal sensor pattern"
    else:
        cause = "healthy"

    return {
        "isSick": is_sick,
        "anomaly_score": float(score),
        "cause": cause
    }

def run(raw_data):
    try:
        data = json.loads(raw_data)

        if isinstance(data, list):
            results = []
            for animal in data:
                result = analyze_animal(animal)
                result["animal_id"] = animal.get("animal_id", "unknown")
                result["species"]   = animal.get("animal_type", "unknown")
                results.append(result)

            sick_animals = [r for r in results if r["isSick"]]
            return {
                "total_animals": len(results),
                "sick_count":    len(sick_animals),
                "healthy_count": len(results) - len(sick_animals),
                "animals":       results,
                "alert":         len(sick_animals) > 0
            }
        else:
            result = analyze_animal(data)
            result["animal_id"] = data.get("animal_id", "unknown")
            result["species"]   = data.get("animal_type", "unknown")
            return result

    except Exception as e:
        return {"error": str(e)}