import os
import json
import requests
from azure.ai.ml import MLClient
from azure.ai.ml.entities import (
    ManagedOnlineEndpoint,
    ManagedOnlineDeployment,
    Model,
    Environment,
    CodeConfiguration
)
from azure.ai.ml.constants import AssetTypes
from azure.identity import DefaultAzureCredential

# -------------------------------------------------------------------
# 1. Azure connection details
# -------------------------------------------------------------------
subscription_id = "1c0707ec-aff3-4d02-a08a-ac5b7769245f"
resource_group = "livestock_rg"
workspace_name = "livestockML"

credential = DefaultAzureCredential()
ml_client = MLClient(
    credential=credential,
    subscription_id=subscription_id,
    resource_group_name=resource_group,
    workspace_name=workspace_name
)

# -------------------------------------------------------------------
# 2. Create folder and move model files (only if not already moved)
# -------------------------------------------------------------------
os.makedirs("model_artifacts", exist_ok=True)

if os.path.exists("sheep_anomaly_model.pkl"):
    os.replace("sheep_anomaly_model.pkl", "model_artifacts/sheep_anomaly_model.pkl")

if os.path.exists("scaler.pkl"):
    os.replace("scaler.pkl", "model_artifacts/scaler.pkl")

# -------------------------------------------------------------------
# 3. Register the model folder
# -------------------------------------------------------------------
model_name = "sheep-anomaly-model"

registered_model = ml_client.models.create_or_update(
    Model(
        path="./model_artifacts",
        type=AssetTypes.CUSTOM_MODEL,
        name=model_name,
        description="Isolation Forest model with scaler for sheep health anomaly detection"
        # No hardcoded version — Azure ML auto-increments it
    )
)
print(f"Registered model: {registered_model.name} version {registered_model.version}")

# -------------------------------------------------------------------
# 4. Define the environment
# -------------------------------------------------------------------
env = Environment(
    image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04:latest",
    conda_file="conda.yaml",
    name="sheep-env-v2",
    description="Environment for sheep anomaly detection"
)
registered_env = ml_client.environments.create_or_update(env)
print(f"Environment registered: {registered_env.name}:{registered_env.version}")

# -------------------------------------------------------------------
# 5. Create or reuse the online endpoint
# -------------------------------------------------------------------
endpoint_name = "sheep-anomaly-endpoint"

try:
    endpoint = ml_client.online_endpoints.get(name=endpoint_name)
    print(f"Endpoint '{endpoint_name}' already exists.")
except Exception:
    endpoint = ManagedOnlineEndpoint(
        name=endpoint_name,
        description="Endpoint for sheep health anomaly detection",
        auth_mode="key"
    )
    ml_client.online_endpoints.begin_create_or_update(endpoint).wait()
    print(f"Created endpoint '{endpoint_name}'.")

# -------------------------------------------------------------------
# 6. Create the deployment — reference registered env by name:version
# -------------------------------------------------------------------
deployment_name = "blue"

deployment = ManagedOnlineDeployment(
    name=deployment_name,
    endpoint_name=endpoint_name,
    model=f"{registered_model.name}:{registered_model.version}",
    environment=f"{registered_env.name}:{registered_env.version}",  # FIX: use registered ref
    code_configuration=CodeConfiguration(
        code="./",
        scoring_script="score.py"
    ),
    instance_type="Standard_DS3_v2",   # FIX: DS2 is often too small, use DS3
    instance_count=1
)

print(f"Deploying '{deployment_name}' to endpoint '{endpoint_name}'...")
ml_client.online_deployments.begin_create_or_update(deployment).wait()
print("Deployment complete.")

# -------------------------------------------------------------------
# 7. Route 100% traffic to this deployment
# -------------------------------------------------------------------
endpoint = ml_client.online_endpoints.get(name=endpoint_name)
endpoint.traffic = {deployment_name: 100}
ml_client.online_endpoints.begin_create_or_update(endpoint).wait()
print("Traffic assigned.")

# -------------------------------------------------------------------
# 7. Route 100% traffic to this deployment
# -------------------------------------------------------------------
endpoint = ml_client.online_endpoints.get(name=endpoint_name)
endpoint.traffic = {deployment_name: 100}
ml_client.online_endpoints.begin_create_or_update(endpoint).wait()
print("Traffic assigned.")
print("Deployment complete. Run predict.py to start predictions.")