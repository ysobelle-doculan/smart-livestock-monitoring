import json
import requests
from azure.cosmos import CosmosClient
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential
from datetime import datetime

# -------------------------------------------------------------------
# CONFIG
# -------------------------------------------------------------------
COSMOS_ENDPOINT = "https://farmlinkcosmosdb.documents.azure.com:443/"
COSMOS_KEY      = "EKfgTSLTGpiBhf7GFWWTUzzSsBgLWQ4ykLIPWyl07bwsvR3M9al1cHh6lr11aaj1Lzn1KMfgXdA6ACDbITplpg=="
DATABASE_NAME   = "farmlinkDB"

subscription_id = "1c0707ec-aff3-4d02-a08a-ac5b7769245f"
resource_group  = "livestock_rg"
workspace_name  = "livestockML"
endpoint_name   = "sheep-anomaly-endpoint"

# -------------------------------------------------------------------
# 1. Connect to Azure ML endpoint
# -------------------------------------------------------------------
def get_endpoint():
    credential = DefaultAzureCredential()
    ml_client  = MLClient(
        credential=credential,
        subscription_id=subscription_id,
        resource_group_name=resource_group,
        workspace_name=workspace_name
    )
    scoring_uri = ml_client.online_endpoints.get(name=endpoint_name).scoring_uri
    primary_key = ml_client.online_endpoints.get_keys(name=endpoint_name).primary_key
    return scoring_uri, primary_key

# -------------------------------------------------------------------
# 2. Fetch latest sensor readings from Telemetry container
# -------------------------------------------------------------------
def fetch_readings():
    client    = CosmosClient(COSMOS_ENDPOINT, credential=COSMOS_KEY)
    container = client \
        .get_database_client(DATABASE_NAME) \
        .get_container_client("Telemetry")

    query    = "SELECT * FROM c"
    readings = list(container.query_items(
        query=query,
        enable_cross_partition_query=True
    ))

    print(f"Fetched {len(readings)} readings from Telemetry.")
    return readings

# -------------------------------------------------------------------
# 3. Send to ML endpoint
# -------------------------------------------------------------------
def predict(readings, scoring_uri, primary_key):
    payload = [
        {
            "animal_id":        r["animalID"],
            "animal_type":      r.get("species", "unknown"),
            "motion_level":     r["motion_level"],
            "heart_rate_bpm":   r["heart_rate_bpm"],
            "respiration_rate": r.get("respiration_rate", 18.0),
            "body_temp_c":      r["body_temp_c"],
            "env_temp_c":       r["env_temp_c"]
        }
        for r in readings
    ]

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {primary_key}"
    }

    response = requests.post(scoring_uri, data=json.dumps(payload), headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"ML endpoint error [{response.status_code}]: {response.text}")

# -------------------------------------------------------------------
# 4. Save predictions to HealthStatus container
# -------------------------------------------------------------------
def save_results(predictions):
    client    = CosmosClient(COSMOS_ENDPOINT, credential=COSMOS_KEY)
    container = client \
        .get_database_client(DATABASE_NAME) \
        .get_container_client("HealthStatus")

    timestamp = datetime.utcnow().isoformat()

    for i, animal in enumerate(predictions["animals"]):
        doc = {
            "id":            f"{animal['animal_id']}-{timestamp}-{i}",
            "animalID":      animal["animal_id"],
            "species":       animal.get("species", "unknown"),
            "isSick":        animal["isSick"],
            "anomaly_score": animal["anomaly_score"],
            "cause":         animal["cause"],
            "timestamp":     timestamp
        }
        container.upsert_item(doc)
        print(f"  Saved: {animal['animal_id']} → {animal['cause']}")
# 5. Display results
# -------------------------------------------------------------------
def display_results(predictions):
    print(f"\n{'='*50}")
    print(f"  HERD REPORT — {datetime.utcnow().isoformat()}")
    print(f"{'='*50}")
    print(f"  Total   : {predictions['total_animals']}")
    print(f"  Sick    : {predictions['sick_count']}")
    print(f"  Healthy : {predictions['healthy_count']}")
    print(f"{'='*50}")

    if predictions["alert"]:
        print("\n  🚨 ALERT — SICK ANIMALS DETECTED\n")
    else:
        print("\n  ✅ All animals healthy.\n")

    for animal in predictions["animals"]:
        status = "❌ SICK   " if animal["isSick"] else "✅ HEALTHY"
        print(f"  {status} | {animal['animal_id']:<12} | {animal['cause']}")

    print(f"{'='*50}\n")

# -------------------------------------------------------------------
# 6. Run
# -------------------------------------------------------------------
def run():
    print("Connecting to Azure ML endpoint...")
    scoring_uri, primary_key = get_endpoint()

    print("Fetching latest readings from Telemetry...")
    readings = fetch_readings()

    if not readings:
        print("No readings found in Telemetry container.")
        return

    print(f"Found {len(readings)} animals. Running predictions...")
    predictions = predict(readings, scoring_uri, primary_key)

    print("Raw response:", predictions)

    print("Saving results to HealthStatus...")
    save_results(predictions)

    print("Done.")

if __name__ == "__main__":
    run()