import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
import json
import joblib

# -------------------------------
# 2. Load dataset
# -------------------------------
df = pd.read_csv("livestock_dataset.csv")
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp')
df = df.ffill()

# -------------------------------
# 3. Select features
# -------------------------------
features = [
    "motion_level",
    "respiration_rate",
    "heart_rate_bpm",
    "body_temp_c",
    "env_temp_c"
]
X = df[features]

# -------------------------------
# 4. Feature scaling
# -------------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -------------------------------
# 5. Train Isolation Forest
# -------------------------------
model = IsolationForest(
    n_estimators=100,
    contamination=0.12,
    random_state=42
)
model.fit(X_scaled)

# -------------------------------
# 6. Generate predictions
# -------------------------------
df['anomaly'] = model.predict(X_scaled)
df['anomaly'] = df['anomaly'].map({1: 0, -1: 1})
df['anomaly_score'] = model.decision_function(X_scaled)

print("Anomaly counts:")
print(df['anomaly'].value_counts())

# -------------------------------
# 7. Unhealthy animals per species
# -------------------------------
summary = df.groupby(['species', 'animalID'])['anomaly'].sum().reset_index()
summary.rename(columns={'anomaly': 'anomaly_count'}, inplace=True)
summary['unhealthy'] = summary['anomaly_count'] > 0
print("\nUnhealthy summary:")
print(summary)

# -------------------------------
# 8. Save results
# -------------------------------
df.to_csv("livestock_anomaly_results.csv", index=False)
summary.to_csv("livestock_unhealthy_summary.csv", index=False)

# -------------------------------
# 9. Visualize
# -------------------------------
plt.figure(figsize=(12, 5))
plt.scatter(df['timestamp'], df['body_temp_c'], c=df['anomaly'], cmap='coolwarm')
plt.xlabel("Time")
plt.ylabel("Body Temperature (°C)")
plt.title("Livestock Health Anomalies")
plt.savefig("anomaly_plot.png")
print("Plot saved as anomaly_plot.png")

# -------------------------------
# 10. Save model
# -------------------------------
joblib.dump(model, "sheep_anomaly_model.pkl")
joblib.dump(scaler, "scaler.pkl")
print("Model saved!")